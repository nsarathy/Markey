public class CartNotTrackableException extends Exception {
    public CartNotTrackableException(String message) {
        super(message);
    }
}
