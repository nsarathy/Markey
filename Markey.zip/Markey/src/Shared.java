import java.util.Scanner;

public interface Shared {
    Scanner scanner = new Scanner(System.in);
}
